#!/bin/bash

if grep -E -w 'fedora|nobara'  /etc/*release
then
    sudo dnf install feh
fi

if grep -E -w 'arch|Arch'  /etc/*release
then
    sudo pacman -Sy feh
fi

if grep -E -w 'debian|ubunto'  /etc/*release
then
    sudo apt isntall feh
fi
