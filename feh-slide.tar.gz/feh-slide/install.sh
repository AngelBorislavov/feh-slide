#!/bin/bash

sudo pacman -Sy feh