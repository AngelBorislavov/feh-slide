#!/bin/bash
while true
do
feh --bg-scale --randomize ~/Pictures/*
sleep 60
done
